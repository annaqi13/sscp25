from os.path import dirname
from pathlib import Path
MODEL_RESOURCE_DIR = Path(dirname(__file__)) / '../model'
TEST_RESOURCE_DIR = Path(dirname(__file__)) / '../../tests/test_data'